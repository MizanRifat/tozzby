<?php

namespace Webkul\Velocity\Models;

use Konekt\Concord\Proxies\ModelProxy;

class VelocityMetadataProxy extends ModelProxy
{
}