<?php

namespace Webkul\Velocity\Contracts;

interface ContentTranslation
{
}