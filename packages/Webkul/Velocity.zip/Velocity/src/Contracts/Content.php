<?php

namespace Webkul\Velocity\Contracts;

interface Content
{
}