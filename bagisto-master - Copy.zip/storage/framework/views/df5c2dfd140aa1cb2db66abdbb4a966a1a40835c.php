<country-state></country-state>

<?php $__env->startPush('scripts'); ?>

    <script type="text/x-template" id="country-state-template">
        <div>
            <div class="control-group" :class="[errors.has('country') ? 'has-error' : '']">
                <label for="country" class="mandatory">
                    <?php echo e(__('shop::app.customer.account.address.create.country')); ?>

                </label>

                <select type="text" v-validate="'required'" class="control styled-select" id="country" name="country" v-model="country" data-vv-as="&quot;<?php echo e(__('shop::app.customer.account.address.create.country')); ?>&quot;">
                    <option value=""></option>
                    <?php $__currentLoopData = core()->countries(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e($country->code === $defaultCountry ? 'selected' : ''); ?>  value="<?php echo e($country->code); ?>"><?php echo e($country->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <div class="select-icon-container">
                    <span class="select-icon rango-arrow-down"></span>
                </div>

                <span class="control-error" v-if="errors.has('country')">
                    {{ errors.first('country') }}
                </span>
            </div>

            <div class="control-group" :class="[errors.has('state') ? 'has-error' : '']">
                <label for="state" class="mandatory">
                    <?php echo e(__('shop::app.customer.account.address.create.state')); ?>

                </label>

                <input
                    id="state"
                    type="text"
                    name="state"
                    v-model="state"
                    class="control"
                    v-if="!haveStates()"
                    v-validate="'required'"
                    data-vv-as="&quot;<?php echo e(__('shop::app.customer.account.address.create.state')); ?>&quot;" />

                <template v-if="haveStates()">
                    <select
                        id="state"
                        name="state"
                        v-model="state"
                        class="styled-select"
                        v-validate="'required'"
                        data-vv-as="&quot;<?php echo e(__('shop::app.customer.account.address.create.state')); ?>&quot;">

                        <option value=""><?php echo e(__('shop::app.customer.account.address.create.select-state')); ?></option>

                        <option v-for='(state, index) in countryStates[country]' :value="state.code">
                            {{ state.default_name }}
                        </option>
                    </select>

                    <div class="select-icon-container">
                        <span class="select-icon rango-arrow-down"></span>
                    </div>
                </template>

                <span class="control-error" v-if="errors.has('state')">
                    {{ errors.first('state') }}
                </span>
            </div>
        </div>
    </script>

    <script>
        Vue.component('country-state', {

            template: '#country-state-template',

            inject: ['$validator'],

            data() {
                return {
                    country: "<?php echo e($countryCode ?? $defaultCountry); ?>",

                    state: "<?php echo e($stateCode); ?>",

                    countryStates: <?php echo json_encode(core()->groupedStatesByCountries(), 15, 512) ?>
                }
            },

            methods: {
                haveStates() {
                    if (this.countryStates[this.country] && this.countryStates[this.country].length)
                        return true;

                    return false;
                },
            }
        });
    </script>
<?php $__env->stopPush(); ?><?php /**PATH C:\xampp\htdocs\bagisto-master/resources/themes/velocity/views/customers/account/address/country-state.blade.php ENDPATH**/ ?>