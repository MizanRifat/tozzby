<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
    <head>
        <meta http-equiv="Cache-control" content="no-cache">

        <style type="text/css">
            body, th, td, h5 {
                font-size: 12px;
                color: #000;
            }

            .container {
                padding: 20px;
                display: block;
            }

            .invoice-summary {
                margin-bottom: 20px;
            }

            .table {
                margin-top: 20px;
            }

            .table table {
                width: 100%;
                border-collapse: collapse;
                text-align: left;
                table-layout: fixed;
            }

            .table thead th {
                font-weight: 700;
                border-top: solid 1px #d3d3d3;
                border-bottom: solid 1px #d3d3d3;
                border-left: solid 1px #d3d3d3;
                padding: 5px 10px;
                background: #F4F4F4;
            }

            .table thead th:last-child {
                border-right: solid 1px #d3d3d3;
            }

            .table tbody td {
                padding: 5px 10px;
                border-bottom: solid 1px #d3d3d3;
                border-left: solid 1px #d3d3d3;
                color: #3A3A3A;
                vertical-align: middle;
                font-family: DejaVu Sans; sans-serif;
            }

            .table tbody td p {
                margin: 0;
            }

            .table tbody td:last-child {
                border-right: solid 1px #d3d3d3;
            }

           .sale-summary {
                margin-top: 40px;
                float: right;
            }

            .sale-summary tr td {
                padding: 3px 5px;
                font-family: DejaVu Sans; sans-serif;
            }

            .sale-summary tr.bold {
                font-family: DejaVu Sans; sans-serif;
                font-weight: 700;
            }

            .label {
                color: #000;
                font-weight: 600;
            }

            .logo {
                height: 70px;
                width: 70px;
            }

        </style>
    </head>

    <body style="background-image: none;background-color: #fff;">
        <div class="container">

            <div class="header">
                <?php if(core()->getConfigData('sales.orderSettings.invoice_slip_design.logo')): ?>
                    <div class="image">
                        <img class="logo" src="<?php echo e(Storage::url(core()->getConfigData('sales.orderSettings.invoice_slip_design.logo'))); ?>"/>
                    </div>
                <?php endif; ?>
                
                <div class="address">
                    <p>
                      <b> <?php echo e(core()->getConfigData('sales.orderSettings.invoice_slip_design.address')); ?> </b>
                    </p>
                </div>
            </div>

            <div class="invoice-summary">

                <div class="row">
                    <span class="label"><?php echo e(__('shop::app.customer.account.order.view.invoice-id')); ?> -</span>
                    <span class="value"><?php echo e($invoice->id); ?></span>
                </div>

                <div class="row">
                    <span class="label"><?php echo e(__('shop::app.customer.account.order.view.order-id')); ?> -</span>
                    <span class="value"><?php echo e($invoice->order->increment_id); ?></span>
                </div>

                <div class="row">
                    <span class="label"><?php echo e(__('shop::app.customer.account.order.view.order-date')); ?> -</span>
                    <span class="value"><?php echo e(core()->formatDate($invoice->order->created_at, 'M d, Y')); ?></span>
                </div>

                <div class="table address">
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 50%"><?php echo e(__('shop::app.customer.account.order.view.bill-to')); ?></th>
                                <?php if($invoice->order->shipping_address): ?>
                                    <th><?php echo e(__('shop::app.customer.account.order.view.ship-to')); ?></th>
                                <?php endif; ?>
                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td>
                                    <p><?php echo e($invoice->order->billing_address->name); ?></p>
                                    <p><?php echo e($invoice->order->billing_address->address1); ?></p>
                                    <p><?php echo e($invoice->order->billing_address->city); ?></p>
                                    <p><?php echo e($invoice->order->billing_address->state); ?></p>
                                    <p>
                                        <?php echo e(core()->country_name($invoice->order->billing_address->country)); ?>

                                        <?php echo e($invoice->order->billing_address->postcode); ?>

                                    </p>
                                    <?php echo e(__('shop::app.customer.account.order.view.contact')); ?> : <?php echo e($invoice->order->billing_address->phone); ?>

                                </td>

                                <?php if($invoice->order->shipping_address): ?>
                                    <td>
                                        <p><?php echo e($invoice->order->shipping_address->name); ?></p>
                                        <p><?php echo e($invoice->order->shipping_address->address1); ?></p>
                                        <p><?php echo e($invoice->order->shipping_address->city); ?></p>
                                        <p><?php echo e($invoice->order->shipping_address->state); ?></p>
                                        <p><?php echo e(core()->country_name($invoice->order->shipping_address->country)); ?> <?php echo e($invoice->order->shipping_address->postcode); ?></p>
                                        <?php echo e(__('shop::app.customer.account.order.view.contact')); ?> : <?php echo e($invoice->order->shipping_address->phone); ?>

                                    </td>
                                <?php endif; ?>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="table payment-shipment">
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 50%"><?php echo e(__('shop::app.customer.account.order.view.payment-method')); ?></th>

                                <?php if($invoice->order->shipping_address): ?>
                                    <th><?php echo e(__('shop::app.customer.account.order.view.shipping-method')); ?></th>
                                <?php endif; ?>
                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td>
                                    <?php echo e(core()->getConfigData('sales.paymentmethods.' . $invoice->order->payment->method . '.title')); ?>

                                </td>

                                <?php if($invoice->order->shipping_address): ?>
                                    <td>
                                        <?php echo e($invoice->order->shipping_title); ?>

                                    </td>
                                <?php endif; ?>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="table items">
                    <table>
                        <thead>
                            <tr>
                                <th><?php echo e(__('shop::app.customer.account.order.view.SKU')); ?></th>
                                <th><?php echo e(__('shop::app.customer.account.order.view.product-name')); ?></th>
                                <th><?php echo e(__('shop::app.customer.account.order.view.price')); ?></th>
                                <th><?php echo e(__('shop::app.customer.account.order.view.qty')); ?></th>
                                <th><?php echo e(__('shop::app.customer.account.order.view.subtotal')); ?></th>
                                <th><?php echo e(__('shop::app.customer.account.order.view.tax-amount')); ?></th>
                                <th><?php echo e(__('shop::app.customer.account.order.view.grand-total')); ?></th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->child ? $item->child->sku : $item->sku); ?></td>

                                    <td>
                                        <?php echo e($item->name); ?>


                                        <?php if(isset($item->additional['attributes'])): ?>
                                            <div class="item-options">

                                                <?php $__currentLoopData = $item->additional['attributes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <b><?php echo e($attribute['attribute_name']); ?> : </b><?php echo e($attribute['option_label']); ?></br>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </div>
                                        <?php endif; ?>
                                    </td>

                                    <td><?php echo e(core()->formatPrice($item->price, $invoice->order->order_currency_code)); ?></td>

                                    <td><?php echo e($item->qty); ?></td>

                                    <td><?php echo e(core()->formatPrice($item->total, $invoice->order->order_currency_code)); ?></td>

                                    <td><?php echo e(core()->formatPrice($item->tax_amount, $invoice->order->order_currency_code)); ?></td>

                                    <td><?php echo e(core()->formatPrice(($item->total + $item->tax_amount), $invoice->order->order_currency_code)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>


                <table class="sale-summary">
                    <tr>
                        <td><?php echo e(__('shop::app.customer.account.order.view.subtotal')); ?></td>
                        <td>-</td>
                        <td><?php echo e(core()->formatPrice($invoice->sub_total, $invoice->order->order_currency_code)); ?></td>
                    </tr>

                    <tr>
                        <td><?php echo e(__('shop::app.customer.account.order.view.shipping-handling')); ?></td>
                        <td>-</td>
                        <td><?php echo e(core()->formatPrice($invoice->shipping_amount, $invoice->order->order_currency_code)); ?></td>
                    </tr>

                    <?php if($invoice->base_discount_amount > 0): ?>
                        <tr>
                            <td><?php echo e(__('shop::app.customer.account.order.view.discount')); ?></td>
                            <td>-</td>
                            <td><?php echo e(core()->formatPrice($invoice->discount_amount, $invoice->order_currency_code)); ?></td>
                        </tr>
                    <?php endif; ?>

                    <tr>
                        <td><?php echo e(__('shop::app.customer.account.order.view.tax')); ?></td>
                        <td>-</td>
                        <td><?php echo e(core()->formatPrice($invoice->tax_amount, $invoice->order->order_currency_code)); ?></td>
                    </tr>

                    <tr class="bold">
                        <td><?php echo e(__('shop::app.customer.account.order.view.grand-total')); ?></td>
                        <td>-</td>
                        <td><?php echo e(core()->formatPrice($invoice->grand_total, $invoice->order->order_currency_code)); ?></td>
                    </tr>
                </table>

            </div>

        </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\bagisto-master\packages\Webkul\Shop\src\Providers/../Resources/views/customers/account/orders/pdf.blade.php ENDPATH**/ ?>