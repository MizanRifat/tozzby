<?php $__env->startSection('page_title'); ?>
    <?php echo e(__('admin::app.promotions.cart-rules.title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content">
        <?php $customer_group = request()->get('customer_group') ?: null; ?>
        <?php $channel = request()->get('channel') ?: null; ?>
        <div class="page-header">
            <div class="page-title">
                <h1><?php echo e(__('admin::app.promotions.cart-rules.title')); ?></h1>
            </div>

            <div class="page-action">
                <div class="control-group">
                    <select class="control" id="channel-switcher" name="channel" onchange="reloadPage('channel', this.value)" >
                        <option value="all" <?php echo e(! isset($channel) ? 'selected' : ''); ?>>
                            <?php echo e(__('admin::app.admin.system.all-channels')); ?>

                        </option>

                        <?php $__currentLoopData = core()->getAllChannels(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channelModel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                value="<?php echo e($channelModel->id); ?>" <?php echo e((isset($channel) && ($channelModel->id) == $channel) ? 'selected' : ''); ?>>
                                <?php echo e($channelModel->name); ?>

                            </option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="control-group">
                    <select class="control" id="customer-group-switcher" name="customer_group" onchange="reloadPage('customer_group', this.value)" >
                        <option value="all" <?php echo e(! isset($locale) ? 'selected' : ''); ?>>
                            <?php echo e(__('admin::app.admin.system.all-customer-groups')); ?>

                        </option>

                        <?php $__currentLoopData = core()->getAllCustomerGroups(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customerGroupModel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                value="<?php echo e($customerGroupModel->id); ?>" <?php echo e((isset($customerGroupModel) && ($customerGroupModel->id) == $customer_group) ? 'selected' : ''); ?>>
                                <?php echo e($customerGroupModel->name); ?>

                            </option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <a href="<?php echo e(route('admin.cart-rules.create')); ?>" class="btn btn-lg btn-primary">
                    <?php echo e(__('admin::app.promotions.cart-rules.add-title')); ?>

                </a>
            </div>
        </div>

        <div class="page-content">
            <?php $cartRuleGrid = app('Webkul\Admin\DataGrids\CartRuleDataGrid'); ?>
            <?php echo $cartRuleGrid->render(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        function reloadPage(getVar, getVal) {
            let url = new URL(window.location.href);
            url.searchParams.set(getVar, getVal);

            window.location.href = url.href;
        }

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin::layouts.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bagisto-master\packages\Webkul\Admin\src\Providers/../Resources/views/promotions/cart-rules/index.blade.php ENDPATH**/ ?>