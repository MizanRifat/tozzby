<div class="pagination">
    <?php echo e($results->links()); ?>

</div><?php /**PATH /var/www/html/bagisto-master/packages/Webkul/Ui/src/Providers/../Resources/views/datagrid/pagination.blade.php ENDPATH**/ ?>