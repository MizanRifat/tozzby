<div class="col-lg-4 col-md-12 col-sm-12 footer-ct-content">
	<div class="row">
        <?php if($velocityMetaData): ?>
            <?php echo $velocityMetaData->footer_middle_content; ?>

        <?php else: ?>
            <div class="col-lg-6 col-md-12 col-sm-12 no-padding">
                <ul type="none">
                    <li><a href="https://webkul.com/about-us/company-profile/">About Us</a></li>
                    <li><a href="https://webkul.com/about-us/company-profile/">Customer Service</a></li>
                    <li><a href="https://webkul.com/about-us/company-profile/">What&rsquo;s New</a></li>
                    <li><a href="https://webkul.com/about-us/company-profile/">Contact Us </a></li>
                </ul>
            </div>
            <div class="col-lg-6 col-md-12 col-sm-12 no-padding">
                <ul type="none">
                    <li><a href="https://webkul.com/about-us/company-profile/"> Order and Returns </a></li>
                    <li><a href="https://webkul.com/about-us/company-profile/"> Payment Policy </a></li>
                    <li><a href="https://webkul.com/about-us/company-profile/"> Shipping Policy</a></li>
                    <li><a href="https://webkul.com/about-us/company-profile/"> Privacy and Cookies Policy </a></li>
                </ul>
            </div>
        <?php endif; ?>
	</div>
</div>
<?php /**PATH C:\xampp\htdocs\bagisto-master - Copy/resources/themes/velocity/views/layouts/footer/footer-links/footer-middle.blade.php ENDPATH**/ ?>